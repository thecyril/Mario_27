// Jason Brillante brilla_a brilla_b
// Epitech 1999-2042
//
//
// Bibliotheque Lapin

# if				!defined(__LAPIN_ADVANCED_H__) && !defined(__LAPIN_BASIC_H__)
#  error This file must not be included alone.
# endif

extern "C" {
