// Jason Brillante "Damdoshi"
// Epitech 1999-2042
//
// Bibliotheque Lapin

#include		"lapin_private.h"

const t_bunny_window	*bunny_get_window(void)
{
  return (gl_window);
}

